# AdditionalDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**boilerType** | **String** |  |  [optional]
**extCovPrdFee** | **String** |  |  [optional]
**pdNettFlg** | **String** |  |  [optional]
**callSource** | [**File**](File.md) | Source |  [optional]
**periodOfCover** | **String** |  |  [optional]
**goodsColour** | **String** |  |  [optional]
**coverType** | **String** |  |  [optional]
**breakdownStartDate** | **String** |  |  [optional]
