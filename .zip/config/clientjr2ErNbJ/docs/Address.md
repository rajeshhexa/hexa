# Address

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**addressCategory** | **String** |  |  [optional]
**addressOverride** | **String** |  |  [optional]
**addressStatus** | **String** |  |  [optional]
**addressDetails** | [**AddressDetails**](AddressDetails.md) |  |  [optional]
