# AddressDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**addressLine1** | **String** |  |  [optional]
**addressLine2** | **String** |  |  [optional]
**addressLine3** | **String** |  |  [optional]
**addressLine4** | **String** |  |  [optional]
**postalCode** | **String** |  |  [optional]
**countryCode** | **String** |  |  [optional]
