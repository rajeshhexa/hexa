# NewBabyPlanList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**newBabyPlan** | [**NewBabyPlan**](NewBabyPlan.md) |  |  [optional]
