# Plan

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**companyCode** | **String** |  |  [optional]
**schemeCode** | **String** |  |  [optional]
**reference** | **String** |  |  [optional]
