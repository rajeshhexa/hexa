# RTPPaymentDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**preferredPayment** | **String** |  |  [optional]
**paymentType** | **String** |  |  [optional]
**paymentProfile** | **String** |  |  [optional]
**cashPaymentType** | **String** |  |  [optional]
**numberOfPayments** | **String** |  |  [optional]
**paymentFrequency** | **String** |  |  [optional]
**firstPayment** | **String** |  |  [optional]
**subsequentPayment** | **String** |  |  [optional]
**excessAmount** | **String** |  |  [optional]
**rtPRates** | [**RTPRates**](RTPRates.md) |  |  [optional]
