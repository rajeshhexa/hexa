# Scheme

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**companyCode** | **String** |  |  [optional]
**schemeCode** | **String** |  |  [optional]
**telRegMakerCode** | **String** |  |  [optional]
