# SourceID

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clientUserId** | **String** |  |  [optional]
**password** | **String** |  |  [optional]
