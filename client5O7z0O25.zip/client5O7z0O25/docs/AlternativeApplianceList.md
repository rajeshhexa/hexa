# AlternativeApplianceList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alternativeAppliance** | [**AlternativeAppliance**](AlternativeAppliance.md) |  |  [optional]
