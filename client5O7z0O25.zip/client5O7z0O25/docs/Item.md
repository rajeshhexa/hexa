# Item

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**itemLink** | [**ItemLink**](ItemLink.md) |  |  [optional]
**itemDetails** | [**ItemDetails**](ItemDetails.md) |  |  [optional]
**additionalDetails** | [**AdditionalDetails**](AdditionalDetails.md) |  |  [optional]
**otherIds** | [**OtherIds**](OtherIds.md) |  |  [optional]
**cover** | [**Cover**](Cover.md) |  |  [optional]
**purchase** | [**Purchase**](Purchase.md) |  |  [optional]
**address** | [**Address**](Address.md) |  |  [optional]
**personOwnerList** | [**PersonOwnerList**](PersonOwnerList.md) |  |  [optional]
**personUserList** | [**PersonUserList**](PersonUserList.md) |  |  [optional]
**clientCode** | **String** |  |  [optional]
**itemCtgCode** | **String** |  |  [optional]
