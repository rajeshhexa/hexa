# AffectedSecurities

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | affected Securities Id | [optional] 
**name** | **str** |  | [optional] 
**symbol** | **str** |  | [optional] 
**isin** | **str** |  | [optional] 
**action_details** | [**ActionDetails**](ActionDetails.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

