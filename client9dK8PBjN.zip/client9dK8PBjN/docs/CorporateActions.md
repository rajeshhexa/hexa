# CorporateActions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Corporate Actions Id | [optional] 
**type** | **str** |  | [optional] 
**record_date** | **str** |  | [optional] 
**ex_date** | **str** |  | [optional] 
**payment_date** | **str** |  | [optional] 
**issuer** | [**Issuer**](Issuer.md) |  | [optional] 
**affected_securities** | [**AffectedSecurities**](AffectedSecurities.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

