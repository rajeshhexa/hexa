# BabyPlan

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**companyCode** | **String** |  |  [optional]
**schemeCode** | **String** |  |  [optional]
**reference** | **String** |  |  [optional]
**itemCode** | [**LocalDate**](LocalDate.md) | Unique ID of Item |  [optional]
**modelNumber1** | **String** |  |  [optional]
**modelNumber2** | **String** |  |  [optional]
**errorMessage** | **String** |  |  [optional]
