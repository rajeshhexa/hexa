# BabyPlanList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**babyPlan** | [**BabyPlan**](BabyPlan.md) |  |  [optional]
