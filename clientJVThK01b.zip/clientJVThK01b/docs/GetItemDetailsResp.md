# GetItemDetailsResp

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**source** | [**Source**](Source.md) |  |  [optional]
**itemDetailsList** | [**ItemDetailsList**](ItemDetailsList.md) |  |  [optional]
**errorResponseList** | [**ErrorResponseList**](ErrorResponseList.md) |  |  [optional]
