# ItemID

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EID** | **String** | employee ID |  [optional]
