# ItemLink

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**memIdNum** | **String** |  |  [optional]
**srcCode** | **String** |  |  [optional]
