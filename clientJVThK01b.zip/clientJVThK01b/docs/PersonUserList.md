# PersonUserList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**personUser** | [**PersonUser**](PersonUser.md) |  |  [optional]
