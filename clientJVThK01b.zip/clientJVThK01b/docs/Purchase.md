# Purchase

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**purchasePrice** | **String** |  |  [optional]
**priceCurrencyCode** | **String** |  |  [optional]
**purchaseDate** | **String** |  |  [optional]
**purchaseTime** | **String** |  |  [optional]
**recommendedPrice** | **String** |  |  [optional]
**recommendedPriceCurrencyCode** | **String** |  |  [optional]
**purchaseRetailer** | **String** |  |  [optional]
