# RTPOfferReference

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offerReference** | **String** |  |  [optional]
**offerKey** | **String** |  |  [optional]
**callSource** | [**File**](File.md) | Source |  [optional]
