# RTPRateList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rtPRate** | [**RTPRate**](RTPRate.md) |  |  [optional]
