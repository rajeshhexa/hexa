# CreateItemReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sourceEvent** | [**SourceEvent**](SourceEvent.md) |  |  [optional]
**isItemOwned** | **String** |  |  [optional]
**itemID** | [**ItemID**](ItemID.md) |  |  [optional]
**itemURN** | [**ItemURN**](ItemURN.md) |  |  [optional]
**item** | [**Item**](Item.md) |  |  [optional]
**registerMailer** | **String** |  |  [optional]
**itemGetPriceDetails** | [**ItemGetPriceDetails**](ItemGetPriceDetails.md) |  |  [optional]
**customerToken** | **String** |  |  [optional]
**personEID** | **String** |  |  [optional]
**mailerDetails** | [**MailerDetails**](MailerDetails.md) |  |  [optional]
