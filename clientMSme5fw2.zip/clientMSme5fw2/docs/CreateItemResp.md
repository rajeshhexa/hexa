# CreateItemResp

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**itemID** | [**ItemID**](ItemID.md) |  |  [optional]
**itemURN** | [**ItemURN**](ItemURN.md) |  |  [optional]
**mailer** | [**Mailer**](Mailer.md) |  |  [optional]
**rtPOfferReferenceList** | [**RTPOfferReferenceList**](RTPOfferReferenceList.md) |  |  [optional]
**rtPRateList** | [**RTPRateList**](RTPRateList.md) |  |  [optional]
**alternativeApplianceList** | [**AlternativeApplianceList**](AlternativeApplianceList.md) |  |  [optional]
**errorResponseList** | [**ErrorResponseList**](ErrorResponseList.md) |  |  [optional]
