# GetPriceCallSourceList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**callSource** | [**File**](File.md) | Source |  [optional]
