# ItemURNList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**itemURN** | [**ItemURN**](ItemURN.md) |  |  [optional]
