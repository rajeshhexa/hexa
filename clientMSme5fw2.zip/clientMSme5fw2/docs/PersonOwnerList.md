# PersonOwnerList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**personOwner** | [**PersonOwner**](PersonOwner.md) |  |  [optional]
