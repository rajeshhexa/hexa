# SwaggerPetstore.Pets

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
