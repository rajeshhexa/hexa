# CorporateActionsApiV1.AffectedSecurities

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**symbol** | **String** |  | [optional] 
**name** | **String** |  | [optional] 
**id** | **String** | affected Securities Id | [optional] 
**actionDetails** | [**ActionDetails**](ActionDetails.md) |  | [optional] 
**ISIN** | **String** |  | [optional] 
