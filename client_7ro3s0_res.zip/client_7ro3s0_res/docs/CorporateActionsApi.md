# CorporateActionsApiV1.CorporateActionsApi

All URIs are relative to *&lt;to be set&gt;*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createCorporateActions**](CorporateActionsApi.md#createCorporateActions) | **POST** /corporateActions | Create Corporate Action
[**deleteCorporateAction**](CorporateActionsApi.md#deleteCorporateAction) | **DELETE** /corporateActions/{id} | Delete Corporate Action By Id
[**getCorporateActions**](CorporateActionsApi.md#getCorporateActions) | **GET** /corporateActions | Get All Corporate Actions
[**getCorporateActionsById**](CorporateActionsApi.md#getCorporateActionsById) | **GET** /corporateActions/{id} | Get Corporate Action By Id
[**updateCorporateAction**](CorporateActionsApi.md#updateCorporateAction) | **PUT** /corporateActions/{id} | Update Corporate Action By Id

<a name="createCorporateActions"></a>
# **createCorporateActions**
> EntityResponse createCorporateActions(body)

Create Corporate Action

Create Corporate Action

### Example
```javascript
import {CorporateActionsApiV1} from 'corporate_actions_api_v1';
let defaultClient = CorporateActionsApiV1.ApiClient.instance;
// Configure HTTP basic authorization: BasicAuth
let BasicAuth = defaultClient.authentications['BasicAuth'];
BasicAuth.username = 'YOUR USERNAME';
BasicAuth.password = 'YOUR PASSWORD';

let apiInstance = new CorporateActionsApiV1.CorporateActionsApi();
let body = new CorporateActionsApiV1.CorporateActions(); // CorporateActions | 

apiInstance.createCorporateActions(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CorporateActions**](CorporateActions.md)|  | 

### Return type

[**EntityResponse**](EntityResponse.md)

### Authorization

[BasicAuth](../README.md#BasicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="deleteCorporateAction"></a>
# **deleteCorporateAction**
> &#x27;String&#x27; deleteCorporateAction(id)

Delete Corporate Action By Id

Delete Corporate Action By Id

### Example
```javascript
import {CorporateActionsApiV1} from 'corporate_actions_api_v1';
let defaultClient = CorporateActionsApiV1.ApiClient.instance;
// Configure HTTP basic authorization: BasicAuth
let BasicAuth = defaultClient.authentications['BasicAuth'];
BasicAuth.username = 'YOUR USERNAME';
BasicAuth.password = 'YOUR PASSWORD';

let apiInstance = new CorporateActionsApiV1.CorporateActionsApi();
let id = "id_example"; // String | Id of Corporate Action to get details

apiInstance.deleteCorporateAction(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Id of Corporate Action to get details | 

### Return type

**&#x27;String&#x27;**

### Authorization

[BasicAuth](../README.md#BasicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getCorporateActions"></a>
# **getCorporateActions**
> [CorporateActions] getCorporateActions()

Get All Corporate Actions

Get All Corporate Actions

### Example
```javascript
import {CorporateActionsApiV1} from 'corporate_actions_api_v1';
let defaultClient = CorporateActionsApiV1.ApiClient.instance;
// Configure HTTP basic authorization: BasicAuth
let BasicAuth = defaultClient.authentications['BasicAuth'];
BasicAuth.username = 'YOUR USERNAME';
BasicAuth.password = 'YOUR PASSWORD';

let apiInstance = new CorporateActionsApiV1.CorporateActionsApi();
apiInstance.getCorporateActions((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**[CorporateActions]**](CorporateActions.md)

### Authorization

[BasicAuth](../README.md#BasicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getCorporateActionsById"></a>
# **getCorporateActionsById**
> CorporateActions getCorporateActionsById(id)

Get Corporate Action By Id

Get Corporate Action By Id

### Example
```javascript
import {CorporateActionsApiV1} from 'corporate_actions_api_v1';
let defaultClient = CorporateActionsApiV1.ApiClient.instance;
// Configure HTTP basic authorization: BasicAuth
let BasicAuth = defaultClient.authentications['BasicAuth'];
BasicAuth.username = 'YOUR USERNAME';
BasicAuth.password = 'YOUR PASSWORD';

let apiInstance = new CorporateActionsApiV1.CorporateActionsApi();
let id = "id_example"; // String | Id of Corporate Action to get details

apiInstance.getCorporateActionsById(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Id of Corporate Action to get details | 

### Return type

[**CorporateActions**](CorporateActions.md)

### Authorization

[BasicAuth](../README.md#BasicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="updateCorporateAction"></a>
# **updateCorporateAction**
> EntityResponse updateCorporateAction(body, id)

Update Corporate Action By Id

Update Corporate Action By Id

### Example
```javascript
import {CorporateActionsApiV1} from 'corporate_actions_api_v1';
let defaultClient = CorporateActionsApiV1.ApiClient.instance;
// Configure HTTP basic authorization: BasicAuth
let BasicAuth = defaultClient.authentications['BasicAuth'];
BasicAuth.username = 'YOUR USERNAME';
BasicAuth.password = 'YOUR PASSWORD';

let apiInstance = new CorporateActionsApiV1.CorporateActionsApi();
let body = new CorporateActionsApiV1.CorporateActions(); // CorporateActions | 
let id = "id_example"; // String | Id of Corporate Action to get details

apiInstance.updateCorporateAction(body, id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CorporateActions**](CorporateActions.md)|  | 
 **id** | **String**| Id of Corporate Action to get details | 

### Return type

[**EntityResponse**](EntityResponse.md)

### Authorization

[BasicAuth](../README.md#BasicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

