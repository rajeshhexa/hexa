# CorporateActionsApiV1.Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errorDescription** | **String** |  | [optional] 
**errorCode** | **String** |  | [optional] 
