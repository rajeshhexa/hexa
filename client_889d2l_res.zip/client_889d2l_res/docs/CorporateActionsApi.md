# swagger_client.CorporateActionsApi

All URIs are relative to *&lt;to be set&gt;*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_corporate_actions**](CorporateActionsApi.md#create_corporate_actions) | **POST** /corporateActions | Create Corporate Action
[**delete_corporate_action**](CorporateActionsApi.md#delete_corporate_action) | **DELETE** /corporateActions/{id} | Delete Corporate Action By Id
[**get_corporate_actions**](CorporateActionsApi.md#get_corporate_actions) | **GET** /corporateActions | Get All Corporate Actions
[**get_corporate_actions_by_id**](CorporateActionsApi.md#get_corporate_actions_by_id) | **GET** /corporateActions/{id} | Get Corporate Action By Id
[**update_corporate_action**](CorporateActionsApi.md#update_corporate_action) | **PUT** /corporateActions/{id} | Update Corporate Action By Id

# **create_corporate_actions**
> EntityResponse create_corporate_actions(body)

Create Corporate Action

Create Corporate Action

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint
# Configure HTTP basic authorization: BasicAuth
configuration = swagger_client.Configuration()
configuration.username = 'YOUR_USERNAME'
configuration.password = 'YOUR_PASSWORD'

# create an instance of the API class
api_instance = swagger_client.CorporateActionsApi(swagger_client.ApiClient(configuration))
body = swagger_client.CorporateActions() # CorporateActions | 

try:
    # Create Corporate Action
    api_response = api_instance.create_corporate_actions(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CorporateActionsApi->create_corporate_actions: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CorporateActions**](CorporateActions.md)|  | 

### Return type

[**EntityResponse**](EntityResponse.md)

### Authorization

[BasicAuth](../README.md#BasicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_corporate_action**
> str delete_corporate_action(id)

Delete Corporate Action By Id

Delete Corporate Action By Id

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint
# Configure HTTP basic authorization: BasicAuth
configuration = swagger_client.Configuration()
configuration.username = 'YOUR_USERNAME'
configuration.password = 'YOUR_PASSWORD'

# create an instance of the API class
api_instance = swagger_client.CorporateActionsApi(swagger_client.ApiClient(configuration))
id = 'id_example' # str | Id of Corporate Action to get details

try:
    # Delete Corporate Action By Id
    api_response = api_instance.delete_corporate_action(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CorporateActionsApi->delete_corporate_action: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| Id of Corporate Action to get details | 

### Return type

**str**

### Authorization

[BasicAuth](../README.md#BasicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_corporate_actions**
> list[CorporateActions] get_corporate_actions()

Get All Corporate Actions

Get All Corporate Actions

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint
# Configure HTTP basic authorization: BasicAuth
configuration = swagger_client.Configuration()
configuration.username = 'YOUR_USERNAME'
configuration.password = 'YOUR_PASSWORD'

# create an instance of the API class
api_instance = swagger_client.CorporateActionsApi(swagger_client.ApiClient(configuration))

try:
    # Get All Corporate Actions
    api_response = api_instance.get_corporate_actions()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CorporateActionsApi->get_corporate_actions: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**list[CorporateActions]**](CorporateActions.md)

### Authorization

[BasicAuth](../README.md#BasicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_corporate_actions_by_id**
> CorporateActions get_corporate_actions_by_id(id)

Get Corporate Action By Id

Get Corporate Action By Id

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint
# Configure HTTP basic authorization: BasicAuth
configuration = swagger_client.Configuration()
configuration.username = 'YOUR_USERNAME'
configuration.password = 'YOUR_PASSWORD'

# create an instance of the API class
api_instance = swagger_client.CorporateActionsApi(swagger_client.ApiClient(configuration))
id = 'id_example' # str | Id of Corporate Action to get details

try:
    # Get Corporate Action By Id
    api_response = api_instance.get_corporate_actions_by_id(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CorporateActionsApi->get_corporate_actions_by_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| Id of Corporate Action to get details | 

### Return type

[**CorporateActions**](CorporateActions.md)

### Authorization

[BasicAuth](../README.md#BasicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_corporate_action**
> EntityResponse update_corporate_action(body, id)

Update Corporate Action By Id

Update Corporate Action By Id

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint
# Configure HTTP basic authorization: BasicAuth
configuration = swagger_client.Configuration()
configuration.username = 'YOUR_USERNAME'
configuration.password = 'YOUR_PASSWORD'

# create an instance of the API class
api_instance = swagger_client.CorporateActionsApi(swagger_client.ApiClient(configuration))
body = swagger_client.CorporateActions() # CorporateActions | 
id = 'id_example' # str | Id of Corporate Action to get details

try:
    # Update Corporate Action By Id
    api_response = api_instance.update_corporate_action(body, id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CorporateActionsApi->update_corporate_action: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CorporateActions**](CorporateActions.md)|  | 
 **id** | **str**| Id of Corporate Action to get details | 

### Return type

[**EntityResponse**](EntityResponse.md)

### Authorization

[BasicAuth](../README.md#BasicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

