# CorporateActions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ex_date** | **str** |  | [optional] 
**affected_securities** | [**AffectedSecurities**](AffectedSecurities.md) |  | [optional] 
**record_date** | **str** |  | [optional] 
**id** | **str** | Corporate Actions Id | [optional] 
**type** | **str** |  | [optional] 
**payment_date** | **str** |  | [optional] 
**issuer** | [**Issuer**](Issuer.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

