# Cover

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**manufacturerGuaranteeLabourMonths** | **String** |  |  [optional]
**manufacturerGuaranteePartsMonths** | **String** |  |  [optional]
**thirdPartyGuaranteeLabourMonths** | **String** |  |  [optional]
**thirdPartyGuaranteePartsMonths** | **String** |  |  [optional]
