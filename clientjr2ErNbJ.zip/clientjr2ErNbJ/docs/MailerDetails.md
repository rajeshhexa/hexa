# MailerDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**regCode** | **String** |  |  [optional]
**prodQTypeID** | **String** |  |  [optional]
**boilerType** | **String** |  |  [optional]
**language** | **String** |  |  [optional]
