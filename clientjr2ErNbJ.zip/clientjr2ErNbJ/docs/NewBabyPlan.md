# NewBabyPlan

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**itemID** | [**ItemID**](ItemID.md) |  |  [optional]
**itemURN** | [**ItemURN**](ItemURN.md) |  |  [optional]
**mailer** | [**Mailer**](Mailer.md) |  |  [optional]
**item** | [**Item**](Item.md) |  |  [optional]
