# RTPOfferDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offerReference** | **String** |  |  [optional]
**offerKey** | **String** |  |  [optional]
**offerPricingKey** | **String** |  |  [optional]
**periodOfCover** | **String** |  |  [optional]
**fee** | **String** |  |  [optional]
**waitDays** | **String** |  |  [optional]
**wicType** | **String** |  |  [optional]
**multiplanType** | **String** |  |  [optional]
**multiplanWarrantyType** | **String** |  |  [optional]
**rtPPaymentDetails** | [**RTPPaymentDetails**](RTPPaymentDetails.md) |  |  [optional]
