# RTPOfferReferenceList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rtPOfferReference** | [**RTPOfferReference**](RTPOfferReference.md) |  |  [optional]
