# RTPRate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**callSourceDetails** | [**CallSourceDetails**](CallSourceDetails.md) |  |  [optional]
**rtPOfferDetails** | [**RTPOfferDetails**](RTPOfferDetails.md) |  |  [optional]
