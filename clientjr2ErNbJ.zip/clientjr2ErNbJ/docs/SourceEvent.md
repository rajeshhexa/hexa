# SourceEvent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**businessEventSourceCode** | **String** |  |  [optional]
**businessEventCode** | **String** |  |  [optional]
**receivedDate** | **String** |  |  [optional]
**receivedTime** | **String** |  |  [optional]
**logonUserId** | **String** |  |  [optional]
