export * from './orders.service';
import { OrdersService } from './orders.service';
export const APIS = [OrdersService];
