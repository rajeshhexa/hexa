# AdditionalDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**boilerType** | **String** |  |  [optional]
**extCovPrdFee** | **String** |  |  [optional]
**pdNettFlg** | **String** |  |  [optional]
**callSource** | **String** |  |  [optional]
**periodOfCover** | **String** |  |  [optional]
**goodsColour** | **String** |  |  [optional]
**coverType** | **String** |  |  [optional]
**breakdownStartDate** | **String** |  |  [optional]
