# Agent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agentNumber** | **String** |  |  [optional]
**schemeCodeBranchNumber** | **String** |  |  [optional]
