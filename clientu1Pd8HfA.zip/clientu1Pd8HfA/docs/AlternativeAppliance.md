# AlternativeAppliance

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**companyCode** | **String** |  |  [optional]
**schemeCode** | **String** |  |  [optional]
**itemGroupCode** | **String** |  |  [optional]
**itemCode** | **String** |  |  [optional]
**itemDescription** | **String** |  |  [optional]
