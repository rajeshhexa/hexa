# ContractType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productCategory** | **String** |  |  [optional]
**productCategoryDesc** | **String** |  |  [optional]
**productType** | **String** |  |  [optional]
**productTypeDesc** | **String** |  |  [optional]
**productVariance** | **String** |  |  [optional]
**productVarianceDesc** | **String** |  |  [optional]
**paymentTerm** | **String** |  |  [optional]
**paymentTermDesc** | **String** |  |  [optional]
**contractTypeCode** | **String** |  |  [optional]
**contractTypeDesc** | **String** |  |  [optional]
**productDescription** | **String** |  |  [optional]
