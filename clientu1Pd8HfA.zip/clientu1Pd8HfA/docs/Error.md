# Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errorCode** | **String** |  |  [optional]
**errorDescription** | **String** |  |  [optional]
