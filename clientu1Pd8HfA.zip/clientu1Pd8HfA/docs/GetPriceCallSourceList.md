# GetPriceCallSourceList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**callSource** | **String** |  |  [optional]
