# ItemDetailsList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**itemDetails** | [**ItemDetails**](ItemDetails.md) |  |  [optional]
