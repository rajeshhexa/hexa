# ItemGetPriceDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**itemCreateOffer** | **String** |  |  [optional]
**getPriceCallSourceList** | [**GetPriceCallSourceList**](GetPriceCallSourceList.md) |  |  [optional]
