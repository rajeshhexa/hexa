# ItemID

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EID** | **String** |  |  [optional]
