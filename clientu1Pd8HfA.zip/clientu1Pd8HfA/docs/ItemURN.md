# ItemURN

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clientURN** | **String** |  |  [optional]
**applianceToken** | **String** |  |  [optional]
