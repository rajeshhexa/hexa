# OtherIds

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**otherId1** | **String** |  |  [optional]
**otherId1CategoryCode** | **String** |  |  [optional]
**otherId2** | **String** |  |  [optional]
**otherId2CategoryCode** | **String** |  |  [optional]
**otherId3** | **String** |  |  [optional]
**otherId3CategoryCode** | **String** |  |  [optional]
**otherModelId1** | **String** |  |  [optional]
**otherModelId1CategoryCode** | **String** |  |  [optional]
**otherModelId2** | **String** |  |  [optional]
**otherModelId2CategoryCode** | **String** |  |  [optional]
