# PersonOwner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**previousClientURN** | **String** |  |  [optional]
**clientURN** | **String** |  |  [optional]
**previousEID** | **String** |  |  [optional]
**EID** | **String** |  |  [optional]
**srcCode** | **String** |  |  [optional]
