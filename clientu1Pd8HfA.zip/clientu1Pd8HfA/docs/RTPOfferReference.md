# RTPOfferReference

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offerReference** | **String** |  |  [optional]
**offerKey** | **String** |  |  [optional]
**callSource** | **String** |  |  [optional]
