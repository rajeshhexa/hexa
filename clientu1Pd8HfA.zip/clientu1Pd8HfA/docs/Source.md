# Source

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**channelCode** | **String** |  |  [optional]
**channelGroupCode** | **String** |  |  [optional]
**systemCode** | **String** |  |  [optional]
**countryCode** | **String** |  |  [optional]
**clientCode** | **String** |  |  [optional]
**clientCodeDescription** | **String** |  |  [optional]
**clientGroupCode** | **String** |  |  [optional]
**clientGroupDescription** | **String** |  |  [optional]
