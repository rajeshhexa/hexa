# UpdateItemReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sourceEvent** | [**SourceEvent**](SourceEvent.md) |  |  [optional]
**itemID** | [**ItemID**](ItemID.md) |  |  [optional]
**itemURN** | [**ItemURN**](ItemURN.md) |  |  [optional]
**item** | [**Item**](Item.md) |  |  [optional]
**plan** | [**Plan**](Plan.md) |  |  [optional]
**isNewBabyPlan** | **String** |  |  [optional]
**newBabyPlanList** | [**NewBabyPlanList**](NewBabyPlanList.md) |  |  [optional]
**mailer** | [**Mailer**](Mailer.md) |  |  [optional]
**updateMailerStatus** | **String** |  |  [optional]
**customerToken** | **String** |  |  [optional]
**ovrBabyBSD** | **String** |  |  [optional]
