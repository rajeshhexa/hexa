# UpdateItemResp

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**itemID** | [**ItemID**](ItemID.md) |  |  [optional]
**itemURN** | [**ItemURN**](ItemURN.md) |  |  [optional]
**babyPlanList** | [**BabyPlanList**](BabyPlanList.md) |  |  [optional]
**errorResponseList** | [**ErrorResponseList**](ErrorResponseList.md) |  |  [optional]
