package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OtherIds
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-04-18T11:49:38.614906200Z[Etc/UTC]")


public class OtherIds   {
  @JsonProperty("OtherId1")
  private String otherId1 = null;

  @JsonProperty("OtherId1CategoryCode")
  private String otherId1CategoryCode = null;

  @JsonProperty("OtherId2")
  private String otherId2 = null;

  @JsonProperty("OtherId2CategoryCode")
  private String otherId2CategoryCode = null;

  @JsonProperty("OtherId3")
  private String otherId3 = null;

  @JsonProperty("OtherId3CategoryCode")
  private String otherId3CategoryCode = null;

  @JsonProperty("OtherModelId1")
  private String otherModelId1 = null;

  @JsonProperty("OtherModelId1CategoryCode")
  private String otherModelId1CategoryCode = null;

  @JsonProperty("OtherModelId2")
  private String otherModelId2 = null;

  @JsonProperty("OtherModelId2CategoryCode")
  private String otherModelId2CategoryCode = null;

  public OtherIds otherId1(String otherId1) {
    this.otherId1 = otherId1;
    return this;
  }

  /**
   * Get otherId1
   * @return otherId1
   **/
  @Schema(description = "")
  
    public String getOtherId1() {
    return otherId1;
  }

  public void setOtherId1(String otherId1) {
    this.otherId1 = otherId1;
  }

  public OtherIds otherId1CategoryCode(String otherId1CategoryCode) {
    this.otherId1CategoryCode = otherId1CategoryCode;
    return this;
  }

  /**
   * Get otherId1CategoryCode
   * @return otherId1CategoryCode
   **/
  @Schema(description = "")
  
    public String getOtherId1CategoryCode() {
    return otherId1CategoryCode;
  }

  public void setOtherId1CategoryCode(String otherId1CategoryCode) {
    this.otherId1CategoryCode = otherId1CategoryCode;
  }

  public OtherIds otherId2(String otherId2) {
    this.otherId2 = otherId2;
    return this;
  }

  /**
   * Get otherId2
   * @return otherId2
   **/
  @Schema(description = "")
  
    public String getOtherId2() {
    return otherId2;
  }

  public void setOtherId2(String otherId2) {
    this.otherId2 = otherId2;
  }

  public OtherIds otherId2CategoryCode(String otherId2CategoryCode) {
    this.otherId2CategoryCode = otherId2CategoryCode;
    return this;
  }

  /**
   * Get otherId2CategoryCode
   * @return otherId2CategoryCode
   **/
  @Schema(description = "")
  
    public String getOtherId2CategoryCode() {
    return otherId2CategoryCode;
  }

  public void setOtherId2CategoryCode(String otherId2CategoryCode) {
    this.otherId2CategoryCode = otherId2CategoryCode;
  }

  public OtherIds otherId3(String otherId3) {
    this.otherId3 = otherId3;
    return this;
  }

  /**
   * Get otherId3
   * @return otherId3
   **/
  @Schema(description = "")
  
    public String getOtherId3() {
    return otherId3;
  }

  public void setOtherId3(String otherId3) {
    this.otherId3 = otherId3;
  }

  public OtherIds otherId3CategoryCode(String otherId3CategoryCode) {
    this.otherId3CategoryCode = otherId3CategoryCode;
    return this;
  }

  /**
   * Get otherId3CategoryCode
   * @return otherId3CategoryCode
   **/
  @Schema(description = "")
  
    public String getOtherId3CategoryCode() {
    return otherId3CategoryCode;
  }

  public void setOtherId3CategoryCode(String otherId3CategoryCode) {
    this.otherId3CategoryCode = otherId3CategoryCode;
  }

  public OtherIds otherModelId1(String otherModelId1) {
    this.otherModelId1 = otherModelId1;
    return this;
  }

  /**
   * Get otherModelId1
   * @return otherModelId1
   **/
  @Schema(description = "")
  
    public String getOtherModelId1() {
    return otherModelId1;
  }

  public void setOtherModelId1(String otherModelId1) {
    this.otherModelId1 = otherModelId1;
  }

  public OtherIds otherModelId1CategoryCode(String otherModelId1CategoryCode) {
    this.otherModelId1CategoryCode = otherModelId1CategoryCode;
    return this;
  }

  /**
   * Get otherModelId1CategoryCode
   * @return otherModelId1CategoryCode
   **/
  @Schema(description = "")
  
    public String getOtherModelId1CategoryCode() {
    return otherModelId1CategoryCode;
  }

  public void setOtherModelId1CategoryCode(String otherModelId1CategoryCode) {
    this.otherModelId1CategoryCode = otherModelId1CategoryCode;
  }

  public OtherIds otherModelId2(String otherModelId2) {
    this.otherModelId2 = otherModelId2;
    return this;
  }

  /**
   * Get otherModelId2
   * @return otherModelId2
   **/
  @Schema(description = "")
  
    public String getOtherModelId2() {
    return otherModelId2;
  }

  public void setOtherModelId2(String otherModelId2) {
    this.otherModelId2 = otherModelId2;
  }

  public OtherIds otherModelId2CategoryCode(String otherModelId2CategoryCode) {
    this.otherModelId2CategoryCode = otherModelId2CategoryCode;
    return this;
  }

  /**
   * Get otherModelId2CategoryCode
   * @return otherModelId2CategoryCode
   **/
  @Schema(description = "")
  
    public String getOtherModelId2CategoryCode() {
    return otherModelId2CategoryCode;
  }

  public void setOtherModelId2CategoryCode(String otherModelId2CategoryCode) {
    this.otherModelId2CategoryCode = otherModelId2CategoryCode;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OtherIds otherIds = (OtherIds) o;
    return Objects.equals(this.otherId1, otherIds.otherId1) &&
        Objects.equals(this.otherId1CategoryCode, otherIds.otherId1CategoryCode) &&
        Objects.equals(this.otherId2, otherIds.otherId2) &&
        Objects.equals(this.otherId2CategoryCode, otherIds.otherId2CategoryCode) &&
        Objects.equals(this.otherId3, otherIds.otherId3) &&
        Objects.equals(this.otherId3CategoryCode, otherIds.otherId3CategoryCode) &&
        Objects.equals(this.otherModelId1, otherIds.otherModelId1) &&
        Objects.equals(this.otherModelId1CategoryCode, otherIds.otherModelId1CategoryCode) &&
        Objects.equals(this.otherModelId2, otherIds.otherModelId2) &&
        Objects.equals(this.otherModelId2CategoryCode, otherIds.otherModelId2CategoryCode);
  }

  @Override
  public int hashCode() {
    return Objects.hash(otherId1, otherId1CategoryCode, otherId2, otherId2CategoryCode, otherId3, otherId3CategoryCode, otherModelId1, otherModelId1CategoryCode, otherModelId2, otherModelId2CategoryCode);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OtherIds {\n");
    
    sb.append("    otherId1: ").append(toIndentedString(otherId1)).append("\n");
    sb.append("    otherId1CategoryCode: ").append(toIndentedString(otherId1CategoryCode)).append("\n");
    sb.append("    otherId2: ").append(toIndentedString(otherId2)).append("\n");
    sb.append("    otherId2CategoryCode: ").append(toIndentedString(otherId2CategoryCode)).append("\n");
    sb.append("    otherId3: ").append(toIndentedString(otherId3)).append("\n");
    sb.append("    otherId3CategoryCode: ").append(toIndentedString(otherId3CategoryCode)).append("\n");
    sb.append("    otherModelId1: ").append(toIndentedString(otherModelId1)).append("\n");
    sb.append("    otherModelId1CategoryCode: ").append(toIndentedString(otherModelId1CategoryCode)).append("\n");
    sb.append("    otherModelId2: ").append(toIndentedString(otherModelId2)).append("\n");
    sb.append("    otherModelId2CategoryCode: ").append(toIndentedString(otherModelId2CategoryCode)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
