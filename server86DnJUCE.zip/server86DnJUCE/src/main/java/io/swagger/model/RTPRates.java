package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * RTPRates
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-04-18T11:49:38.614906200Z[Etc/UTC]")


public class RTPRates   {
  @JsonProperty("OfferPricingDetailsKey")
  private String offerPricingDetailsKey = null;

  @JsonProperty("LevelOfCover")
  private String levelOfCover = null;

  @JsonProperty("ItemCode")
  private String itemCode = null;

  @JsonProperty("PayProfile")
  private String payProfile = null;

  @JsonProperty("PeriodOfCover")
  private String periodOfCover = null;

  @JsonProperty("ServiceFee")
  private String serviceFee = null;

  @JsonProperty("Price")
  private String price = null;

  @JsonProperty("NetFee")
  private String netFee = null;

  @JsonProperty("GrossFee")
  private String grossFee = null;

  @JsonProperty("TotalPrice")
  private String totalPrice = null;

  @JsonProperty("InsPremTax")
  private String insPremTax = null;

  @JsonProperty("SumInsured")
  private String sumInsured = null;

  @JsonProperty("ExcessValue")
  private String excessValue = null;

  @JsonProperty("ClientMargin")
  private String clientMargin = null;

  @JsonProperty("ManuMargin")
  private String manuMargin = null;

  @JsonProperty("Procurement")
  private String procurement = null;

  @JsonProperty("UnderWrtPrem")
  private String underWrtPrem = null;

  @JsonProperty("IPTTaxRate")
  private String ipTTaxRate = null;

  @JsonProperty("PriceBand")
  private String priceBand = null;

  @JsonProperty("RetroMargin")
  private String retroMargin = null;

  @JsonProperty("RetraOvr")
  private String retraOvr = null;

  @JsonProperty("ManufOvr")
  private String manufOvr = null;

  @JsonProperty("SalesStaffInc")
  private String salesStaffInc = null;

  @JsonProperty("CoverCode")
  private String coverCode = null;

  @JsonProperty("ExclusionCode")
  private String exclusionCode = null;

  @JsonProperty("Underwriter")
  private String underwriter = null;

  @JsonProperty("ReserveCode")
  private String reserveCode = null;

  @JsonProperty("ReservePOC")
  private String reservePOC = null;

  @JsonProperty("ReserveMfGuar")
  private String reserveMfGuar = null;

  public RTPRates offerPricingDetailsKey(String offerPricingDetailsKey) {
    this.offerPricingDetailsKey = offerPricingDetailsKey;
    return this;
  }

  /**
   * Get offerPricingDetailsKey
   * @return offerPricingDetailsKey
   **/
  @Schema(description = "")
  
    public String getOfferPricingDetailsKey() {
    return offerPricingDetailsKey;
  }

  public void setOfferPricingDetailsKey(String offerPricingDetailsKey) {
    this.offerPricingDetailsKey = offerPricingDetailsKey;
  }

  public RTPRates levelOfCover(String levelOfCover) {
    this.levelOfCover = levelOfCover;
    return this;
  }

  /**
   * Get levelOfCover
   * @return levelOfCover
   **/
  @Schema(description = "")
  
    public String getLevelOfCover() {
    return levelOfCover;
  }

  public void setLevelOfCover(String levelOfCover) {
    this.levelOfCover = levelOfCover;
  }

  public RTPRates itemCode(String itemCode) {
    this.itemCode = itemCode;
    return this;
  }

  /**
   * Get itemCode
   * @return itemCode
   **/
  @Schema(description = "")
  
    public String getItemCode() {
    return itemCode;
  }

  public void setItemCode(String itemCode) {
    this.itemCode = itemCode;
  }

  public RTPRates payProfile(String payProfile) {
    this.payProfile = payProfile;
    return this;
  }

  /**
   * Get payProfile
   * @return payProfile
   **/
  @Schema(description = "")
  
    public String getPayProfile() {
    return payProfile;
  }

  public void setPayProfile(String payProfile) {
    this.payProfile = payProfile;
  }

  public RTPRates periodOfCover(String periodOfCover) {
    this.periodOfCover = periodOfCover;
    return this;
  }

  /**
   * Get periodOfCover
   * @return periodOfCover
   **/
  @Schema(description = "")
  
    public String getPeriodOfCover() {
    return periodOfCover;
  }

  public void setPeriodOfCover(String periodOfCover) {
    this.periodOfCover = periodOfCover;
  }

  public RTPRates serviceFee(String serviceFee) {
    this.serviceFee = serviceFee;
    return this;
  }

  /**
   * Get serviceFee
   * @return serviceFee
   **/
  @Schema(description = "")
  
    public String getServiceFee() {
    return serviceFee;
  }

  public void setServiceFee(String serviceFee) {
    this.serviceFee = serviceFee;
  }

  public RTPRates price(String price) {
    this.price = price;
    return this;
  }

  /**
   * Get price
   * @return price
   **/
  @Schema(description = "")
  
    public String getPrice() {
    return price;
  }

  public void setPrice(String price) {
    this.price = price;
  }

  public RTPRates netFee(String netFee) {
    this.netFee = netFee;
    return this;
  }

  /**
   * Get netFee
   * @return netFee
   **/
  @Schema(description = "")
  
    public String getNetFee() {
    return netFee;
  }

  public void setNetFee(String netFee) {
    this.netFee = netFee;
  }

  public RTPRates grossFee(String grossFee) {
    this.grossFee = grossFee;
    return this;
  }

  /**
   * Get grossFee
   * @return grossFee
   **/
  @Schema(description = "")
  
    public String getGrossFee() {
    return grossFee;
  }

  public void setGrossFee(String grossFee) {
    this.grossFee = grossFee;
  }

  public RTPRates totalPrice(String totalPrice) {
    this.totalPrice = totalPrice;
    return this;
  }

  /**
   * Get totalPrice
   * @return totalPrice
   **/
  @Schema(description = "")
  
    public String getTotalPrice() {
    return totalPrice;
  }

  public void setTotalPrice(String totalPrice) {
    this.totalPrice = totalPrice;
  }

  public RTPRates insPremTax(String insPremTax) {
    this.insPremTax = insPremTax;
    return this;
  }

  /**
   * Get insPremTax
   * @return insPremTax
   **/
  @Schema(description = "")
  
    public String getInsPremTax() {
    return insPremTax;
  }

  public void setInsPremTax(String insPremTax) {
    this.insPremTax = insPremTax;
  }

  public RTPRates sumInsured(String sumInsured) {
    this.sumInsured = sumInsured;
    return this;
  }

  /**
   * Get sumInsured
   * @return sumInsured
   **/
  @Schema(description = "")
  
    public String getSumInsured() {
    return sumInsured;
  }

  public void setSumInsured(String sumInsured) {
    this.sumInsured = sumInsured;
  }

  public RTPRates excessValue(String excessValue) {
    this.excessValue = excessValue;
    return this;
  }

  /**
   * Get excessValue
   * @return excessValue
   **/
  @Schema(description = "")
  
    public String getExcessValue() {
    return excessValue;
  }

  public void setExcessValue(String excessValue) {
    this.excessValue = excessValue;
  }

  public RTPRates clientMargin(String clientMargin) {
    this.clientMargin = clientMargin;
    return this;
  }

  /**
   * Get clientMargin
   * @return clientMargin
   **/
  @Schema(description = "")
  
    public String getClientMargin() {
    return clientMargin;
  }

  public void setClientMargin(String clientMargin) {
    this.clientMargin = clientMargin;
  }

  public RTPRates manuMargin(String manuMargin) {
    this.manuMargin = manuMargin;
    return this;
  }

  /**
   * Get manuMargin
   * @return manuMargin
   **/
  @Schema(description = "")
  
    public String getManuMargin() {
    return manuMargin;
  }

  public void setManuMargin(String manuMargin) {
    this.manuMargin = manuMargin;
  }

  public RTPRates procurement(String procurement) {
    this.procurement = procurement;
    return this;
  }

  /**
   * Get procurement
   * @return procurement
   **/
  @Schema(description = "")
  
    public String getProcurement() {
    return procurement;
  }

  public void setProcurement(String procurement) {
    this.procurement = procurement;
  }

  public RTPRates underWrtPrem(String underWrtPrem) {
    this.underWrtPrem = underWrtPrem;
    return this;
  }

  /**
   * Get underWrtPrem
   * @return underWrtPrem
   **/
  @Schema(description = "")
  
    public String getUnderWrtPrem() {
    return underWrtPrem;
  }

  public void setUnderWrtPrem(String underWrtPrem) {
    this.underWrtPrem = underWrtPrem;
  }

  public RTPRates ipTTaxRate(String ipTTaxRate) {
    this.ipTTaxRate = ipTTaxRate;
    return this;
  }

  /**
   * Get ipTTaxRate
   * @return ipTTaxRate
   **/
  @Schema(description = "")
  
    public String getIpTTaxRate() {
    return ipTTaxRate;
  }

  public void setIpTTaxRate(String ipTTaxRate) {
    this.ipTTaxRate = ipTTaxRate;
  }

  public RTPRates priceBand(String priceBand) {
    this.priceBand = priceBand;
    return this;
  }

  /**
   * Get priceBand
   * @return priceBand
   **/
  @Schema(description = "")
  
    public String getPriceBand() {
    return priceBand;
  }

  public void setPriceBand(String priceBand) {
    this.priceBand = priceBand;
  }

  public RTPRates retroMargin(String retroMargin) {
    this.retroMargin = retroMargin;
    return this;
  }

  /**
   * Get retroMargin
   * @return retroMargin
   **/
  @Schema(description = "")
  
    public String getRetroMargin() {
    return retroMargin;
  }

  public void setRetroMargin(String retroMargin) {
    this.retroMargin = retroMargin;
  }

  public RTPRates retraOvr(String retraOvr) {
    this.retraOvr = retraOvr;
    return this;
  }

  /**
   * Get retraOvr
   * @return retraOvr
   **/
  @Schema(description = "")
  
    public String getRetraOvr() {
    return retraOvr;
  }

  public void setRetraOvr(String retraOvr) {
    this.retraOvr = retraOvr;
  }

  public RTPRates manufOvr(String manufOvr) {
    this.manufOvr = manufOvr;
    return this;
  }

  /**
   * Get manufOvr
   * @return manufOvr
   **/
  @Schema(description = "")
  
    public String getManufOvr() {
    return manufOvr;
  }

  public void setManufOvr(String manufOvr) {
    this.manufOvr = manufOvr;
  }

  public RTPRates salesStaffInc(String salesStaffInc) {
    this.salesStaffInc = salesStaffInc;
    return this;
  }

  /**
   * Get salesStaffInc
   * @return salesStaffInc
   **/
  @Schema(description = "")
  
    public String getSalesStaffInc() {
    return salesStaffInc;
  }

  public void setSalesStaffInc(String salesStaffInc) {
    this.salesStaffInc = salesStaffInc;
  }

  public RTPRates coverCode(String coverCode) {
    this.coverCode = coverCode;
    return this;
  }

  /**
   * Get coverCode
   * @return coverCode
   **/
  @Schema(description = "")
  
    public String getCoverCode() {
    return coverCode;
  }

  public void setCoverCode(String coverCode) {
    this.coverCode = coverCode;
  }

  public RTPRates exclusionCode(String exclusionCode) {
    this.exclusionCode = exclusionCode;
    return this;
  }

  /**
   * Get exclusionCode
   * @return exclusionCode
   **/
  @Schema(description = "")
  
    public String getExclusionCode() {
    return exclusionCode;
  }

  public void setExclusionCode(String exclusionCode) {
    this.exclusionCode = exclusionCode;
  }

  public RTPRates underwriter(String underwriter) {
    this.underwriter = underwriter;
    return this;
  }

  /**
   * Get underwriter
   * @return underwriter
   **/
  @Schema(description = "")
  
    public String getUnderwriter() {
    return underwriter;
  }

  public void setUnderwriter(String underwriter) {
    this.underwriter = underwriter;
  }

  public RTPRates reserveCode(String reserveCode) {
    this.reserveCode = reserveCode;
    return this;
  }

  /**
   * Get reserveCode
   * @return reserveCode
   **/
  @Schema(description = "")
  
    public String getReserveCode() {
    return reserveCode;
  }

  public void setReserveCode(String reserveCode) {
    this.reserveCode = reserveCode;
  }

  public RTPRates reservePOC(String reservePOC) {
    this.reservePOC = reservePOC;
    return this;
  }

  /**
   * Get reservePOC
   * @return reservePOC
   **/
  @Schema(description = "")
  
    public String getReservePOC() {
    return reservePOC;
  }

  public void setReservePOC(String reservePOC) {
    this.reservePOC = reservePOC;
  }

  public RTPRates reserveMfGuar(String reserveMfGuar) {
    this.reserveMfGuar = reserveMfGuar;
    return this;
  }

  /**
   * Get reserveMfGuar
   * @return reserveMfGuar
   **/
  @Schema(description = "")
  
    public String getReserveMfGuar() {
    return reserveMfGuar;
  }

  public void setReserveMfGuar(String reserveMfGuar) {
    this.reserveMfGuar = reserveMfGuar;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RTPRates rtPRates = (RTPRates) o;
    return Objects.equals(this.offerPricingDetailsKey, rtPRates.offerPricingDetailsKey) &&
        Objects.equals(this.levelOfCover, rtPRates.levelOfCover) &&
        Objects.equals(this.itemCode, rtPRates.itemCode) &&
        Objects.equals(this.payProfile, rtPRates.payProfile) &&
        Objects.equals(this.periodOfCover, rtPRates.periodOfCover) &&
        Objects.equals(this.serviceFee, rtPRates.serviceFee) &&
        Objects.equals(this.price, rtPRates.price) &&
        Objects.equals(this.netFee, rtPRates.netFee) &&
        Objects.equals(this.grossFee, rtPRates.grossFee) &&
        Objects.equals(this.totalPrice, rtPRates.totalPrice) &&
        Objects.equals(this.insPremTax, rtPRates.insPremTax) &&
        Objects.equals(this.sumInsured, rtPRates.sumInsured) &&
        Objects.equals(this.excessValue, rtPRates.excessValue) &&
        Objects.equals(this.clientMargin, rtPRates.clientMargin) &&
        Objects.equals(this.manuMargin, rtPRates.manuMargin) &&
        Objects.equals(this.procurement, rtPRates.procurement) &&
        Objects.equals(this.underWrtPrem, rtPRates.underWrtPrem) &&
        Objects.equals(this.ipTTaxRate, rtPRates.ipTTaxRate) &&
        Objects.equals(this.priceBand, rtPRates.priceBand) &&
        Objects.equals(this.retroMargin, rtPRates.retroMargin) &&
        Objects.equals(this.retraOvr, rtPRates.retraOvr) &&
        Objects.equals(this.manufOvr, rtPRates.manufOvr) &&
        Objects.equals(this.salesStaffInc, rtPRates.salesStaffInc) &&
        Objects.equals(this.coverCode, rtPRates.coverCode) &&
        Objects.equals(this.exclusionCode, rtPRates.exclusionCode) &&
        Objects.equals(this.underwriter, rtPRates.underwriter) &&
        Objects.equals(this.reserveCode, rtPRates.reserveCode) &&
        Objects.equals(this.reservePOC, rtPRates.reservePOC) &&
        Objects.equals(this.reserveMfGuar, rtPRates.reserveMfGuar);
  }

  @Override
  public int hashCode() {
    return Objects.hash(offerPricingDetailsKey, levelOfCover, itemCode, payProfile, periodOfCover, serviceFee, price, netFee, grossFee, totalPrice, insPremTax, sumInsured, excessValue, clientMargin, manuMargin, procurement, underWrtPrem, ipTTaxRate, priceBand, retroMargin, retraOvr, manufOvr, salesStaffInc, coverCode, exclusionCode, underwriter, reserveCode, reservePOC, reserveMfGuar);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RTPRates {\n");
    
    sb.append("    offerPricingDetailsKey: ").append(toIndentedString(offerPricingDetailsKey)).append("\n");
    sb.append("    levelOfCover: ").append(toIndentedString(levelOfCover)).append("\n");
    sb.append("    itemCode: ").append(toIndentedString(itemCode)).append("\n");
    sb.append("    payProfile: ").append(toIndentedString(payProfile)).append("\n");
    sb.append("    periodOfCover: ").append(toIndentedString(periodOfCover)).append("\n");
    sb.append("    serviceFee: ").append(toIndentedString(serviceFee)).append("\n");
    sb.append("    price: ").append(toIndentedString(price)).append("\n");
    sb.append("    netFee: ").append(toIndentedString(netFee)).append("\n");
    sb.append("    grossFee: ").append(toIndentedString(grossFee)).append("\n");
    sb.append("    totalPrice: ").append(toIndentedString(totalPrice)).append("\n");
    sb.append("    insPremTax: ").append(toIndentedString(insPremTax)).append("\n");
    sb.append("    sumInsured: ").append(toIndentedString(sumInsured)).append("\n");
    sb.append("    excessValue: ").append(toIndentedString(excessValue)).append("\n");
    sb.append("    clientMargin: ").append(toIndentedString(clientMargin)).append("\n");
    sb.append("    manuMargin: ").append(toIndentedString(manuMargin)).append("\n");
    sb.append("    procurement: ").append(toIndentedString(procurement)).append("\n");
    sb.append("    underWrtPrem: ").append(toIndentedString(underWrtPrem)).append("\n");
    sb.append("    ipTTaxRate: ").append(toIndentedString(ipTTaxRate)).append("\n");
    sb.append("    priceBand: ").append(toIndentedString(priceBand)).append("\n");
    sb.append("    retroMargin: ").append(toIndentedString(retroMargin)).append("\n");
    sb.append("    retraOvr: ").append(toIndentedString(retraOvr)).append("\n");
    sb.append("    manufOvr: ").append(toIndentedString(manufOvr)).append("\n");
    sb.append("    salesStaffInc: ").append(toIndentedString(salesStaffInc)).append("\n");
    sb.append("    coverCode: ").append(toIndentedString(coverCode)).append("\n");
    sb.append("    exclusionCode: ").append(toIndentedString(exclusionCode)).append("\n");
    sb.append("    underwriter: ").append(toIndentedString(underwriter)).append("\n");
    sb.append("    reserveCode: ").append(toIndentedString(reserveCode)).append("\n");
    sb.append("    reservePOC: ").append(toIndentedString(reservePOC)).append("\n");
    sb.append("    reserveMfGuar: ").append(toIndentedString(reserveMfGuar)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
