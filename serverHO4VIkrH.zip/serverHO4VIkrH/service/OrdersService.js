'use strict';


/**
 * creates an order
 * creates an order
 *
 * body Order 
 * returns order
 **/
exports.createOrder = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "total" : 0.8008281904610115,
  "shippingMethod" : "shippingMethod",
  "basket_Id" : "basket_Id",
  "shippingAddress" : {
    "lastName" : "lastName",
    "country" : "country",
    "phone_mobile" : "phone_mobile",
    "website" : "website",
    "gender" : "gender",
    "identification_number" : "identification_number",
    "address2" : "address2",
    "city" : "city",
    "address1" : "address1",
    "type" : { },
    "tax_id" : "tax_id",
    "firstName" : { },
    "phone" : "phone",
    "postCode" : "postCode",
    "company" : "company",
    "id" : { },
    "state" : "state",
    "fax" : "fax",
    "region" : "region"
  },
  "paymentMethod" : "paymentMethod",
  "discount" : "discount",
  "currency" : "currency",
  "id" : "id",
  "billingAddress" : {
    "lastName" : "lastName",
    "country" : "country",
    "phone_mobile" : "phone_mobile",
    "website" : "website",
    "gender" : "gender",
    "identification_number" : "identification_number",
    "address2" : "address2",
    "city" : "city",
    "address1" : "address1",
    "type" : { },
    "tax_id" : "tax_id",
    "firstName" : { },
    "phone" : "phone",
    "postCode" : "postCode",
    "company" : "company",
    "id" : { },
    "state" : "state",
    "fax" : "fax",
    "region" : "region"
  },
  "createdOn" : "createdOn",
  "customer" : {
    "firstName" : "firstName",
    "lastName" : "lastName",
    "phone" : "phone",
    "id" : { },
    "email" : "email"
  },
  "status" : "status"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * deletes an order by Id
 * deletes an order by Id
 *
 * id String Id of an item to get details
 * returns deleteOrderResp
 **/
exports.deleteOrder = function(id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "status" : "status"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get a Single Order details by passing it's ID
 * get Item details by Id
 *
 * id String Id of an item to get details
 * returns order
 **/
exports.getOrderById = function(id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "total" : 0.8008281904610115,
  "shippingMethod" : "shippingMethod",
  "basket_Id" : "basket_Id",
  "shippingAddress" : {
    "lastName" : "lastName",
    "country" : "country",
    "phone_mobile" : "phone_mobile",
    "website" : "website",
    "gender" : "gender",
    "identification_number" : "identification_number",
    "address2" : "address2",
    "city" : "city",
    "address1" : "address1",
    "type" : { },
    "tax_id" : "tax_id",
    "firstName" : { },
    "phone" : "phone",
    "postCode" : "postCode",
    "company" : "company",
    "id" : { },
    "state" : "state",
    "fax" : "fax",
    "region" : "region"
  },
  "paymentMethod" : "paymentMethod",
  "discount" : "discount",
  "currency" : "currency",
  "id" : "id",
  "billingAddress" : {
    "lastName" : "lastName",
    "country" : "country",
    "phone_mobile" : "phone_mobile",
    "website" : "website",
    "gender" : "gender",
    "identification_number" : "identification_number",
    "address2" : "address2",
    "city" : "city",
    "address1" : "address1",
    "type" : { },
    "tax_id" : "tax_id",
    "firstName" : { },
    "phone" : "phone",
    "postCode" : "postCode",
    "company" : "company",
    "id" : { },
    "state" : "state",
    "fax" : "fax",
    "region" : "region"
  },
  "createdOn" : "createdOn",
  "customer" : {
    "firstName" : "firstName",
    "lastName" : "lastName",
    "phone" : "phone",
    "id" : { },
    "email" : "email"
  },
  "status" : "status"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List all orders
 * List all orders
 *
 * returns order
 **/
exports.listOrders = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "total" : 0.8008281904610115,
  "shippingMethod" : "shippingMethod",
  "basket_Id" : "basket_Id",
  "shippingAddress" : {
    "lastName" : "lastName",
    "country" : "country",
    "phone_mobile" : "phone_mobile",
    "website" : "website",
    "gender" : "gender",
    "identification_number" : "identification_number",
    "address2" : "address2",
    "city" : "city",
    "address1" : "address1",
    "type" : { },
    "tax_id" : "tax_id",
    "firstName" : { },
    "phone" : "phone",
    "postCode" : "postCode",
    "company" : "company",
    "id" : { },
    "state" : "state",
    "fax" : "fax",
    "region" : "region"
  },
  "paymentMethod" : "paymentMethod",
  "discount" : "discount",
  "currency" : "currency",
  "id" : "id",
  "billingAddress" : {
    "lastName" : "lastName",
    "country" : "country",
    "phone_mobile" : "phone_mobile",
    "website" : "website",
    "gender" : "gender",
    "identification_number" : "identification_number",
    "address2" : "address2",
    "city" : "city",
    "address1" : "address1",
    "type" : { },
    "tax_id" : "tax_id",
    "firstName" : { },
    "phone" : "phone",
    "postCode" : "postCode",
    "company" : "company",
    "id" : { },
    "state" : "state",
    "fax" : "fax",
    "region" : "region"
  },
  "createdOn" : "createdOn",
  "customer" : {
    "firstName" : "firstName",
    "lastName" : "lastName",
    "phone" : "phone",
    "id" : { },
    "email" : "email"
  },
  "status" : "status"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * updates an order by Id
 * updates an order by Id
 *
 * body Order 
 * id String Id of an item to get details
 * returns order
 **/
exports.updateOrder = function(body,id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "total" : 0.8008281904610115,
  "shippingMethod" : "shippingMethod",
  "basket_Id" : "basket_Id",
  "shippingAddress" : {
    "lastName" : "lastName",
    "country" : "country",
    "phone_mobile" : "phone_mobile",
    "website" : "website",
    "gender" : "gender",
    "identification_number" : "identification_number",
    "address2" : "address2",
    "city" : "city",
    "address1" : "address1",
    "type" : { },
    "tax_id" : "tax_id",
    "firstName" : { },
    "phone" : "phone",
    "postCode" : "postCode",
    "company" : "company",
    "id" : { },
    "state" : "state",
    "fax" : "fax",
    "region" : "region"
  },
  "paymentMethod" : "paymentMethod",
  "discount" : "discount",
  "currency" : "currency",
  "id" : "id",
  "billingAddress" : {
    "lastName" : "lastName",
    "country" : "country",
    "phone_mobile" : "phone_mobile",
    "website" : "website",
    "gender" : "gender",
    "identification_number" : "identification_number",
    "address2" : "address2",
    "city" : "city",
    "address1" : "address1",
    "type" : { },
    "tax_id" : "tax_id",
    "firstName" : { },
    "phone" : "phone",
    "postCode" : "postCode",
    "company" : "company",
    "id" : { },
    "state" : "state",
    "fax" : "fax",
    "region" : "region"
  },
  "createdOn" : "createdOn",
  "customer" : {
    "firstName" : "firstName",
    "lastName" : "lastName",
    "phone" : "phone",
    "id" : { },
    "email" : "email"
  },
  "status" : "status"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

