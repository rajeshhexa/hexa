package io.swagger.api;

import io.swagger.model.CorporateActions;
import io.swagger.model.EntityResponse;
import io.swagger.model.ErrorResponseList;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.*;
import javax.validation.Valid;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2024-02-07T09:55:58.186837706Z[UTC]")
@RestController
public class CorporateActionsApiController implements CorporateActionsApi {

    private static final Logger log = LoggerFactory.getLogger(CorporateActionsApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public CorporateActionsApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    public ResponseEntity<EntityResponse> createCorporateActions(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody CorporateActions body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<EntityResponse>(objectMapper.readValue("{\n  \"message\" : \"message\",\n  \"statusCode\" : \"statusCode\"\n}", EntityResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<EntityResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<EntityResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<String> deleteCorporateAction(@Parameter(in = ParameterIn.PATH, description = "Id of Corporate Action to get details", required=true, schema=@Schema()) @PathVariable("id") String id) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<String>(objectMapper.readValue("\"\"", String.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<String>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<CorporateActions>> getCorporateActions() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<CorporateActions>>(objectMapper.readValue("[ {\n  \"exDate\" : \"exDate\",\n  \"affectedSecurities\" : {\n    \"symbol\" : \"symbol\",\n    \"name\" : \"name\",\n    \"id\" : \"046b6c7f-0b8a-43b9-b35d-6489e6daee91\",\n    \"actionDetails\" : {\n      \"type\" : \"type\",\n      \"splitRatio\" : \"splitRatio\"\n    },\n    \"ISIN\" : \"ISIN\"\n  },\n  \"recordDate\" : \"recordDate\",\n  \"id\" : \"046b6c7f-0b8a-43b9-b35d-6489e6daee91\",\n  \"type\" : \"type\",\n  \"paymentDate\" : \"paymentDate\",\n  \"issuer\" : {\n    \"name\" : \"name\",\n    \"tickerSymbol\" : \"tickerSymbol\",\n    \"id\" : \"046b6c7f-0b8a-43b9-b35d-6489e6daee91\",\n    \"ISIN\" : \"ISIN\"\n  }\n}, {\n  \"exDate\" : \"exDate\",\n  \"affectedSecurities\" : {\n    \"symbol\" : \"symbol\",\n    \"name\" : \"name\",\n    \"id\" : \"046b6c7f-0b8a-43b9-b35d-6489e6daee91\",\n    \"actionDetails\" : {\n      \"type\" : \"type\",\n      \"splitRatio\" : \"splitRatio\"\n    },\n    \"ISIN\" : \"ISIN\"\n  },\n  \"recordDate\" : \"recordDate\",\n  \"id\" : \"046b6c7f-0b8a-43b9-b35d-6489e6daee91\",\n  \"type\" : \"type\",\n  \"paymentDate\" : \"paymentDate\",\n  \"issuer\" : {\n    \"name\" : \"name\",\n    \"tickerSymbol\" : \"tickerSymbol\",\n    \"id\" : \"046b6c7f-0b8a-43b9-b35d-6489e6daee91\",\n    \"ISIN\" : \"ISIN\"\n  }\n} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<CorporateActions>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<CorporateActions>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<CorporateActions> getCorporateActionsById(@Parameter(in = ParameterIn.PATH, description = "Id of Corporate Action to get details", required=true, schema=@Schema()) @PathVariable("id") String id) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<CorporateActions>(objectMapper.readValue("{\n  \"exDate\" : \"exDate\",\n  \"affectedSecurities\" : {\n    \"symbol\" : \"symbol\",\n    \"name\" : \"name\",\n    \"id\" : \"046b6c7f-0b8a-43b9-b35d-6489e6daee91\",\n    \"actionDetails\" : {\n      \"type\" : \"type\",\n      \"splitRatio\" : \"splitRatio\"\n    },\n    \"ISIN\" : \"ISIN\"\n  },\n  \"recordDate\" : \"recordDate\",\n  \"id\" : \"046b6c7f-0b8a-43b9-b35d-6489e6daee91\",\n  \"type\" : \"type\",\n  \"paymentDate\" : \"paymentDate\",\n  \"issuer\" : {\n    \"name\" : \"name\",\n    \"tickerSymbol\" : \"tickerSymbol\",\n    \"id\" : \"046b6c7f-0b8a-43b9-b35d-6489e6daee91\",\n    \"ISIN\" : \"ISIN\"\n  }\n}", CorporateActions.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<CorporateActions>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<CorporateActions>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<EntityResponse> updateCorporateAction(@Parameter(in = ParameterIn.PATH, description = "Id of Corporate Action to get details", required=true, schema=@Schema()) @PathVariable("id") String id,@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody CorporateActions body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<EntityResponse>(objectMapper.readValue("{\n  \"message\" : \"message\",\n  \"statusCode\" : \"statusCode\"\n}", EntityResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<EntityResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<EntityResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

}
