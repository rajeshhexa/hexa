'use strict';

var utils = require('../utils/writer.js');
var CorporateActions = require('../service/CorporateActionsService');

module.exports.createCorporateActions = function createCorporateActions (req, res, next, body) {
  CorporateActions.createCorporateActions(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteCorporateAction = function deleteCorporateAction (req, res, next, id) {
  CorporateActions.deleteCorporateAction(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getCorporateActions = function getCorporateActions (req, res, next) {
  CorporateActions.getCorporateActions()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getCorporateActionsById = function getCorporateActionsById (req, res, next, id) {
  CorporateActions.getCorporateActionsById(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateCorporateAction = function updateCorporateAction (req, res, next, body, id) {
  CorporateActions.updateCorporateAction(body, id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
