package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ActionDetails
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2024-01-30T18:50:25.608005Z[Etc/UTC]")


public class ActionDetails   {
  @JsonProperty("type")
  private String type = null;

  @JsonProperty("splitRatio")
  private String splitRatio = null;

  public ActionDetails type(String type) {
    this.type = type;
    return this;
  }

  /**
   * Get type
   * @return type
   **/
  @Schema(description = "")
  
    public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public ActionDetails splitRatio(String splitRatio) {
    this.splitRatio = splitRatio;
    return this;
  }

  /**
   * Get splitRatio
   * @return splitRatio
   **/
  @Schema(description = "")
  
    public String getSplitRatio() {
    return splitRatio;
  }

  public void setSplitRatio(String splitRatio) {
    this.splitRatio = splitRatio;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ActionDetails actionDetails = (ActionDetails) o;
    return Objects.equals(this.type, actionDetails.type) &&
        Objects.equals(this.splitRatio, actionDetails.splitRatio);
  }

  @Override
  public int hashCode() {
    return Objects.hash(type, splitRatio);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ActionDetails {\n");
    
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    splitRatio: ").append(toIndentedString(splitRatio)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
