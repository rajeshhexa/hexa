package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.ActionDetails;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.UUID;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * AffectedSecurities
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2024-01-30T18:50:25.608005Z[Etc/UTC]")


public class AffectedSecurities   {
  @JsonProperty("id")
  private UUID id = null;

  @JsonProperty("name")
  private String name = null;

  @JsonProperty("symbol")
  private String symbol = null;

  @JsonProperty("ISIN")
  private String ISIN = null;

  @JsonProperty("actionDetails")
  private ActionDetails actionDetails = null;

  public AffectedSecurities id(UUID id) {
    this.id = id;
    return this;
  }

  /**
   * affected Securities Id
   * @return id
   **/
  @Schema(description = "affected Securities Id")
  
    @Valid
    public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }

  public AffectedSecurities name(String name) {
    this.name = name;
    return this;
  }

  /**
   * Get name
   * @return name
   **/
  @Schema(description = "")
  
    public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public AffectedSecurities symbol(String symbol) {
    this.symbol = symbol;
    return this;
  }

  /**
   * Get symbol
   * @return symbol
   **/
  @Schema(description = "")
  
    public String getSymbol() {
    return symbol;
  }

  public void setSymbol(String symbol) {
    this.symbol = symbol;
  }

  public AffectedSecurities ISIN(String ISIN) {
    this.ISIN = ISIN;
    return this;
  }

  /**
   * Get ISIN
   * @return ISIN
   **/
  @Schema(description = "")
  
    public String getISIN() {
    return ISIN;
  }

  public void setISIN(String ISIN) {
    this.ISIN = ISIN;
  }

  public AffectedSecurities actionDetails(ActionDetails actionDetails) {
    this.actionDetails = actionDetails;
    return this;
  }

  /**
   * Get actionDetails
   * @return actionDetails
   **/
  @Schema(description = "")
  
    @Valid
    public ActionDetails getActionDetails() {
    return actionDetails;
  }

  public void setActionDetails(ActionDetails actionDetails) {
    this.actionDetails = actionDetails;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AffectedSecurities affectedSecurities = (AffectedSecurities) o;
    return Objects.equals(this.id, affectedSecurities.id) &&
        Objects.equals(this.name, affectedSecurities.name) &&
        Objects.equals(this.symbol, affectedSecurities.symbol) &&
        Objects.equals(this.ISIN, affectedSecurities.ISIN) &&
        Objects.equals(this.actionDetails, affectedSecurities.actionDetails);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, symbol, ISIN, actionDetails);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AffectedSecurities {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    symbol: ").append(toIndentedString(symbol)).append("\n");
    sb.append("    ISIN: ").append(toIndentedString(ISIN)).append("\n");
    sb.append("    actionDetails: ").append(toIndentedString(actionDetails)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
