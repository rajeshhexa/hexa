package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.AffectedSecurities;
import io.swagger.model.Issuer;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.UUID;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * CorporateActions
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2024-01-30T18:50:25.608005Z[Etc/UTC]")


public class CorporateActions   {
  @JsonProperty("id")
  private UUID id = null;

  @JsonProperty("type")
  private String type = null;

  @JsonProperty("recordDate")
  private String recordDate = null;

  @JsonProperty("exDate")
  private String exDate = null;

  @JsonProperty("paymentDate")
  private String paymentDate = null;

  @JsonProperty("issuer")
  private Issuer issuer = null;

  @JsonProperty("affectedSecurities")
  private AffectedSecurities affectedSecurities = null;

  public CorporateActions id(UUID id) {
    this.id = id;
    return this;
  }

  /**
   * Corporate Actions Id
   * @return id
   **/
  @Schema(description = "Corporate Actions Id")
  
    @Valid
    public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }

  public CorporateActions type(String type) {
    this.type = type;
    return this;
  }

  /**
   * Get type
   * @return type
   **/
  @Schema(description = "")
  
    public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public CorporateActions recordDate(String recordDate) {
    this.recordDate = recordDate;
    return this;
  }

  /**
   * Get recordDate
   * @return recordDate
   **/
  @Schema(description = "")
  
    public String getRecordDate() {
    return recordDate;
  }

  public void setRecordDate(String recordDate) {
    this.recordDate = recordDate;
  }

  public CorporateActions exDate(String exDate) {
    this.exDate = exDate;
    return this;
  }

  /**
   * Get exDate
   * @return exDate
   **/
  @Schema(description = "")
  
    public String getExDate() {
    return exDate;
  }

  public void setExDate(String exDate) {
    this.exDate = exDate;
  }

  public CorporateActions paymentDate(String paymentDate) {
    this.paymentDate = paymentDate;
    return this;
  }

  /**
   * Get paymentDate
   * @return paymentDate
   **/
  @Schema(description = "")
  
    public String getPaymentDate() {
    return paymentDate;
  }

  public void setPaymentDate(String paymentDate) {
    this.paymentDate = paymentDate;
  }

  public CorporateActions issuer(Issuer issuer) {
    this.issuer = issuer;
    return this;
  }

  /**
   * Get issuer
   * @return issuer
   **/
  @Schema(description = "")
  
    @Valid
    public Issuer getIssuer() {
    return issuer;
  }

  public void setIssuer(Issuer issuer) {
    this.issuer = issuer;
  }

  public CorporateActions affectedSecurities(AffectedSecurities affectedSecurities) {
    this.affectedSecurities = affectedSecurities;
    return this;
  }

  /**
   * Get affectedSecurities
   * @return affectedSecurities
   **/
  @Schema(description = "")
  
    @Valid
    public AffectedSecurities getAffectedSecurities() {
    return affectedSecurities;
  }

  public void setAffectedSecurities(AffectedSecurities affectedSecurities) {
    this.affectedSecurities = affectedSecurities;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CorporateActions corporateActions = (CorporateActions) o;
    return Objects.equals(this.id, corporateActions.id) &&
        Objects.equals(this.type, corporateActions.type) &&
        Objects.equals(this.recordDate, corporateActions.recordDate) &&
        Objects.equals(this.exDate, corporateActions.exDate) &&
        Objects.equals(this.paymentDate, corporateActions.paymentDate) &&
        Objects.equals(this.issuer, corporateActions.issuer) &&
        Objects.equals(this.affectedSecurities, corporateActions.affectedSecurities);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, type, recordDate, exDate, paymentDate, issuer, affectedSecurities);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CorporateActions {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    recordDate: ").append(toIndentedString(recordDate)).append("\n");
    sb.append("    exDate: ").append(toIndentedString(exDate)).append("\n");
    sb.append("    paymentDate: ").append(toIndentedString(paymentDate)).append("\n");
    sb.append("    issuer: ").append(toIndentedString(issuer)).append("\n");
    sb.append("    affectedSecurities: ").append(toIndentedString(affectedSecurities)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
