package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.UUID;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Issuer
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2024-01-30T18:50:25.608005Z[Etc/UTC]")


public class Issuer   {
  @JsonProperty("id")
  private UUID id = null;

  @JsonProperty("name")
  private String name = null;

  @JsonProperty("tickerSymbol")
  private String tickerSymbol = null;

  @JsonProperty("ISIN")
  private String ISIN = null;

  public Issuer id(UUID id) {
    this.id = id;
    return this;
  }

  /**
   * Issuer Id
   * @return id
   **/
  @Schema(description = "Issuer Id")
  
    @Valid
    public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }

  public Issuer name(String name) {
    this.name = name;
    return this;
  }

  /**
   * Get name
   * @return name
   **/
  @Schema(description = "")
  
    public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Issuer tickerSymbol(String tickerSymbol) {
    this.tickerSymbol = tickerSymbol;
    return this;
  }

  /**
   * Get tickerSymbol
   * @return tickerSymbol
   **/
  @Schema(description = "")
  
    public String getTickerSymbol() {
    return tickerSymbol;
  }

  public void setTickerSymbol(String tickerSymbol) {
    this.tickerSymbol = tickerSymbol;
  }

  public Issuer ISIN(String ISIN) {
    this.ISIN = ISIN;
    return this;
  }

  /**
   * Get ISIN
   * @return ISIN
   **/
  @Schema(description = "")
  
    public String getISIN() {
    return ISIN;
  }

  public void setISIN(String ISIN) {
    this.ISIN = ISIN;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Issuer issuer = (Issuer) o;
    return Objects.equals(this.id, issuer.id) &&
        Objects.equals(this.name, issuer.name) &&
        Objects.equals(this.tickerSymbol, issuer.tickerSymbol) &&
        Objects.equals(this.ISIN, issuer.ISIN);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, tickerSymbol, ISIN);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Issuer {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    tickerSymbol: ").append(toIndentedString(tickerSymbol)).append("\n");
    sb.append("    ISIN: ").append(toIndentedString(ISIN)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
