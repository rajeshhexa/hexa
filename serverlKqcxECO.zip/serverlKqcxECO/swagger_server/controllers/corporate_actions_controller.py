import connexion
import six

from swagger_server.models.corporate_actions import CorporateActions  # noqa: E501
from swagger_server.models.entity_response import EntityResponse  # noqa: E501
from swagger_server.models.error_response_list import ErrorResponseList  # noqa: E501
from swagger_server import util


def create_corporate_actions(body):  # noqa: E501
    """Create Corporate Action

    Create Corporate Action # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: EntityResponse
    """
    if connexion.request.is_json:
        body = CorporateActions.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def delete_corporate_action(id):  # noqa: E501
    """Delete Corporate Action By Id

    Delete Corporate Action By Id # noqa: E501

    :param id: Id of Corporate Action to get details
    :type id: str

    :rtype: str
    """
    return 'do some magic!'


def get_corporate_actions():  # noqa: E501
    """Get All Corporate Actions

    Get All Corporate Actions # noqa: E501


    :rtype: List[CorporateActions]
    """
    return 'do some magic!'


def get_corporate_actions_by_id(id):  # noqa: E501
    """Get Corporate Action By Id

    Get Corporate Action By Id # noqa: E501

    :param id: Id of Corporate Action to get details
    :type id: str

    :rtype: CorporateActions
    """
    return 'do some magic!'


def update_corporate_action(body, id):  # noqa: E501
    """Update Corporate Action By Id

    Update Corporate Action By Id # noqa: E501

    :param body: 
    :type body: dict | bytes
    :param id: Id of Corporate Action to get details
    :type id: str

    :rtype: EntityResponse
    """
    if connexion.request.is_json:
        body = CorporateActions.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
